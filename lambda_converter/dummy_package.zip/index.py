import json

def handler(event, context):
    print("Fonction placeholder initialisée.")
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from dummy Lambda!')
    }